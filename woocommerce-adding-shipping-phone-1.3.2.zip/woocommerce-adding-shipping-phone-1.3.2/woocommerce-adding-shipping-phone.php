<?php
/**
 * Plugin Name: WOOCOMMERCE ADDING SHIPPING PHONE
 * Plugin URI: https://www.elechouse.com/
 * Description: Adds a shipping_phone field and requires it when the shipping name differs from the billing name OR the shipping country differs from the billing country. Displays in admin, emails, and formatted shipping address. Includes frontend JS to show the required star dynamically.
 * Version: 1.3.2
 * Author: www.elechouse.com
 * Author URI: https://www.elechouse.com/
 * Text Domain: woocommerce-adding-shipping-phone
 * Domain Path: /languages
 *
 * Support: elechouse@elechouse.com
 */

if (!defined('ABSPATH')) exit;

/**
 * 1) Add shipping_phone to shipping fields (checkout & My Account > Addresses).
 *    The field itself is not strictly required by default; backend validation below enforces it conditionally.
 */
add_filter('woocommerce_shipping_fields', function($fields) {
    $fields['shipping_phone'] = array(
        'label'        => __('Shipping phone', 'woocommerce-adding-shipping-phone'),
        'type'         => 'tel',
        'required'     => false, // Conditional requirement handled in validation hook.
        'priority'     => 120,
        'validate'     => array('phone'),
        'class'        => array('form-row-wide'),
        'autocomplete' => 'tel',
    );
    return $fields;
}, 10);

/**
 * 1.1) Remove "(optional)" hint ONLY for shipping_phone so the label shows as "Shipping phone" even when not required.
 */
add_filter('woocommerce_form_field', function($field, $key, $args, $value){
    if ($key === 'shipping_phone') {
        // Strip the optional span added by WooCommerce for non-required fields
        $field = preg_replace('/<span class="optional">.*?<\/span>/i', '', $field);
    }
    return $field;
}, 10, 4);

/**
 * 1.2) Enqueue frontend script to toggle required star dynamically when conditions are met.
 */
add_action('wp_enqueue_scripts', function(){
    if ( (function_exists('is_checkout') && is_checkout()) || (function_exists('is_account_page') && is_account_page()) ) {
        wp_enqueue_script(
            'woocommerce-adding-shipping-phone-js',
            plugins_url('assets/wc-shipping-phone.js', __FILE__),
            array('jquery'),
            '1.3.2',
            true
        );
    }
});

/**
 * 2) Checkout validation:
 *    When "Ship to a different address" is checked, require Shipping phone if:
 *      - shipping full name != billing full name  OR
 *      - shipping country != billing country
 */
add_action('woocommerce_after_checkout_validation', function($data, $errors){

    // If not shipping to a different address, do nothing.
    if (empty($data['ship_to_different_address'])) {
        return;
    }

    // Normalize names for comparison
    $bn = trim(($data['billing_first_name']  ?? '') . ' ' . ($data['billing_last_name']  ?? ''));
    $sn = trim(($data['shipping_first_name'] ?? '') . ' ' . ($data['shipping_last_name'] ?? ''));
    if (function_exists('mb_strtolower')) {
        $bn_norm = mb_strtolower(preg_replace('/\s+/u', '', $bn));
        $sn_norm = mb_strtolower(preg_replace('/\s+/u', '', $sn));
    } else {
        $bn_norm = strtolower(preg_replace('/\s+/', '', $bn));
        $sn_norm = strtolower(preg_replace('/\s+/', '', $sn));
    }

    // Country codes (e.g., US, CN, PH ...)
    $billing_country  = isset($data['billing_country'])  ? strtoupper(trim($data['billing_country']))  : '';
    $shipping_country = isset($data['shipping_country']) ? strtoupper(trim($data['shipping_country'])) : '';

    $name_diff    = ($bn_norm !== '' && $sn_norm !== '' && $bn_norm !== $sn_norm);
    $country_diff = ($billing_country !== '' && $shipping_country !== '' && $billing_country !== $shipping_country);

    if ($name_diff || $country_diff) {
        $shipping_phone = isset($data['shipping_phone']) ? trim($data['shipping_phone']) : '';

        if ($shipping_phone === '') {
            $errors->add(
                'required-shipping-phone',
                __('Shipping phone is required when the shipping name differs from the billing name or when the shipping country differs from the billing country.', 'woocommerce-adding-shipping-phone')
            );
            return;
        }

        if (class_exists('WC_Validation') && !WC_Validation::is_phone($shipping_phone)) {
            $errors->add(
                'invalid-shipping-phone',
                __('Please enter a valid Shipping phone.', 'woocommerce-adding-shipping-phone')
            );
        }
    }
}, 10, 2);

/**
 * 3) Save to order meta (HPOS & legacy compatible).
 *    If not provided and validation did not require it, optionally fallback to billing_phone (can be removed if undesired).
 */
add_action('woocommerce_checkout_create_order', function($order, $data) {
    $shipping_phone = isset($data['shipping_phone']) ? $data['shipping_phone'] : '';
    if ($shipping_phone === '' && !empty($data['billing_phone'])) {
        $shipping_phone = $data['billing_phone'];
    }
    if ($shipping_phone !== '') {
        $order->update_meta_data('_shipping_phone', wc_clean($shipping_phone));
    }
}, 10, 2);

/**
 * 4) Admin order: display under the shipping address block.
 */
add_action('woocommerce_admin_order_data_after_shipping_address', function($order){
    if (is_object($order) && method_exists($order, 'get_meta')) {
        $phone = $order->get_meta('_shipping_phone');
        if ($phone) {
            echo '<p><strong>' . esc_html__('Shipping phone', 'woocommerce-adding-shipping-phone') . ':</strong> ' . esc_html($phone) . '</p>';
        }
    }
});

/**
 * 6) Formatted Shipping Address (thank you page, order view, order list column, etc.):
 *    append a new line with phone.
 *    IMPORTANT: WooCommerce passes THREE args here: $address (string), $raw_address (array), $order (WC_Order).
 */
add_filter('woocommerce_order_get_formatted_shipping_address', function($address, $raw_address, $order){
    if (is_object($order) && method_exists($order, 'get_meta')) {
        $phone = $order->get_meta('_shipping_phone');
        if ($phone) {
            $address .= "\n" . sprintf('%s: %s', __('Phone', 'woocommerce-adding-shipping-phone'), $phone);
        }
    }
    return $address;
}, 10, 3);

/**
 * 5) Emails: show in the customer details section.
 */
add_filter('woocommerce_email_customer_details_fields', function($fields, $sent_to_admin, $order){
    if (is_object($order) && method_exists($order, 'get_meta')) {
        $phone = $order->get_meta('_shipping_phone');
        if ($phone) {
            $fields['shipping_phone'] = array(
                'label' => __('Shipping phone', 'woocommerce-adding-shipping-phone'),
                'value' => $phone,
            );
        }
    }
    return $fields;
}, 10, 3);
