=== WOOCOMMERCE ADDING SHIPPING PHONE ===
Contributors: elechouse
Plugin URI: https://www.elechouse.com/
Tags: woocommerce, checkout, shipping phone, validation
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.3.2
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds a shipping_phone field and requires it when the shipping name differs from the billing name OR the shipping country differs from the billing country. Shows in admin, emails, and formatted shipping address. Frontend JS dynamically adds/removes the required star.

== Description ==
- Adds shipping_phone to shipping address forms
- Removes the "(optional)" hint for this field
- Validates on checkout when (name differs) OR (country differs)
- Saves to order meta _shipping_phone (HPOS-compatible)
- Displays in admin order, emails, and formatted shipping address
- Frontend JS: dynamically shows the required star and HTML5 required attribute

== Support ==
Website: https://www.elechouse.com/
Email: elechouse@elechouse.com

== Installation ==
1. Upload the ZIP via Plugins > Add New > Upload Plugin, or unzip to wp-content/plugins/woocommerce-adding-shipping-phone/
2. Activate the plugin
3. Test checkout

== Changelog ==
= 1.3.2 =
* Release metadata update: plugin name, author website, support email; align text domain with slug

= 1.3.1 =
* Fix fatal error: accept 3 args for woocommerce_order_get_formatted_shipping_address; add type checks

= 1.3.0 =
* Add frontend JS to toggle required star and HTML5 required attribute when (name OR country) differs

= 1.2.0 =
* Require on name OR country difference, English-only messages, remove optional label

= 1.1.0 =
* Initial release
