(function($){
  function normName(first, last){
    var s = (String(first||'').trim() + ' ' + String(last||'').trim()).replace(/\s+/g,'');
    return s.toLowerCase();
  }
  function shouldRequire(){
    var shipDiff = $('#ship-to-different-address input, #ship-to-different-address-checkbox').is(':checked');
    if(!shipDiff){ return false; }

    var bn = normName($('#billing_first_name').val(),  $('#billing_last_name').val());
    var sn = normName($('#shipping_first_name').val(), $('#shipping_last_name').val());

    var bc = String($('#billing_country').val()  || '').trim().toUpperCase();
    var sc = String($('#shipping_country').val() || '').trim().toUpperCase();

    var nameDiff    = (bn && sn && bn !== sn);
    var countryDiff = (bc && sc && bc !== sc);

    return nameDiff || countryDiff;
  }

  function toggleRequired(){
    var $fieldWrap = $('#shipping_phone_field'); // WooCommerce wrapper div
    var $input     = $('#shipping_phone');
    if(!$input.length || !$fieldWrap.length) return;

    // always remove (optional) if any (theme may inject)
    $fieldWrap.find('span.optional').remove();

    if(shouldRequire()){
      // add required attr & class
      $input.attr('required', 'required');
      $fieldWrap.addClass('validate-required');

      // add required star if missing
      var $label = $fieldWrap.find('label');
      if($label.length && !$label.find('abbr.required').length){
        $label.append(' <abbr class="required" title="required">*</abbr>');
      }
    }else{
      // remove required state but keep "(optional)" removed as requested
      $input.removeAttr('required');
      $fieldWrap.removeClass('validate-required');
      // remove star if present
      $fieldWrap.find('abbr.required').remove();
    }
  }

  function bind(){
    var sel = [
      '#ship-to-different-address input', '#ship-to-different-address-checkbox',
      '#billing_first_name', '#billing_last_name',
      '#shipping_first_name', '#shipping_last_name',
      '#billing_country', '#shipping_country'
    ].join(',');

    $(document.body).on('change keyup', sel, toggleRequired);
    $(document.body).on('updated_checkout', toggleRequired); // Woo event
  }

  $(function(){
    bind();
    // initial run after small delay to wait for WC JS to build fields
    setTimeout(toggleRequired, 80);
  });
})(jQuery);
